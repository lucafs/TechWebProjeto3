import React from "react";
export class DropdownHeroes extends React.Component {
 constructor(props){  
    super(props) 
    this.state = {
    heroes: [],
    heroeSelecionado: "",
  };}

  componentDidMount() {

    fetch("https://api.opendota.com/api/heroStats")
      .then(response => {
        return response.json();
      })
      .then(data => {
        let heroesDaAPI = data.map(heroi => {
          return { value: heroi.id, display: heroi.localized_name };
        });
        this.setState({
          heroes: heroesDaAPI
          
        });
      })
      .catch(error => {
        console.log(error);
      });
  }
  onChangeHeroisSelecionado(){
      this.props.changeId(this.state.heroeSelecionado)
  }  

  render() {
    return (
      <div>
        <div>
          <select value={this.state.heroeSelecionado}
            onChange={e => {this.setState({ heroeSelecionado:e.target.value},this.onChangeHeroisSelecionado.bind(this))}}
            >
            {this.state.heroes.map(heroe => (
              <option key={heroe.value} value={heroe.value}>
                {heroe.display}
              </option>
            ))}
          </select>
        </div>
      </div>
    );
  }
}
export default DropdownHeroes;