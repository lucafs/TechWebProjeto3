import Navbar from "react-bootstrap/Navbar";
import Nav from "react-bootstrap/Nav";
import {Link} from "react-router-dom"
import React from "react";
import Matchups from "./Matchups"
import App from "../App"
import { BrowserRouter as Router, Route } from "react-router-dom";


class Header extends React.Component {
  render() {
    return (
      <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
        <Navbar.Brand href="/">Dota 2 Win Rates</Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav">
          <Nav className="mr-auto">
                <Nav.Link href="matchup">WinRates for specific Hero</Nav.Link>


          </Nav>
        </Navbar.Collapse>
      </Navbar>
    );
  }
}
export default Header;
