import "bootstrap/dist/css/bootstrap.min.css";
import Card from "react-bootstrap/Card";
import React from "react";

class MatchupCard extends React.Component {
    constructor(props){
        super(props);
        this.setState({
            heroStats:[],
            localized_name:""
        })
    }

  render() {
    return (
        <Card style={{ width: "14rem" }}>
        <Card.Img variant="top" src={`https://api.opendota.com${this.props.img}`} />
        <Card.Body>
          <Card.Title>{this.props .localized_name}</Card.Title>
          <Card.Text>
            {((100 * this.props.win) / this.props.pick).toFixed(2)}% Win Rate
          </Card.Text>
        </Card.Body>
      </Card>
    );
  }
}
export default MatchupCard;
