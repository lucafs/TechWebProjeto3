import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import Card from "react-bootstrap/Card";
const Heroes = props => (
  <Card style={{ width: "14rem" }}>
    <div>{console.log(props.wins)}</div>
    <Card.Img variant="top" src={props.img} />
    <Card.Body>
      <Card.Title>{props.localized_name}</Card.Title>
      <Card.Text>
        {((100 * props.win) / props.pick).toFixed(2)}% Win Rate
      </Card.Text>
    </Card.Body>
  </Card>
);
export default Heroes;
