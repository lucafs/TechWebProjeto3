import axios from "axios";
import React from "react";
import DropdownHeros from "./DropdownHeroes";
import MatchupCard from "./MatchupCard";
import Header from "./Header";
import { BrowserRouter as Router, Route } from "react-router-dom";

class Matchups extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      heroes: [],
      idheroeSelecionado: '2',
      matchups: [],
      total:[],
      URL: `https://api.opendota.com/api/heroes/1/matchups`,
      URL2: "https://api.opendota.com/api/heroStats",
      site: "https://api.opendota.com"
    };
  }
  //-----------------------------------------------//
  async onChangeHeroisSelecionado(newId) {
    const matchups = await axios.get(`https://api.opendota.com/api/heroes/${this.state.idheroeSelecionado}/matchups`).then(({data}) => {
      return data

    });

    var options = matchups.map(function(row) {
      return { id : row.hero_id, games_played : row.games_played ,wins : row.wins }
   })
    var todo=this.joinObjects(this.state.heroes, options)


    this.setState({
      matchups,
      idheroeSelecionado: newId,
      total:todo
    },() => {

    });
    

  }
  //-----------------------------------------------//
//Componente começou
  componentDidMount() {


    Promise.all([fetch(this.state.URL), fetch(this.state.URL2)])

      .then(([res1, res2]) => { 
         return Promise.all([res1.json(), res2.json()]) 
      }) 
      .then(([res1, res2]) => {
        this.setState({
          matchups:res1,
          heroes:res2
        })
      });
  }
    //-----------------------------------------------//

  joinObjects() {
    var idMap = {};
    var key="";
    // Iterate over arguments
    for(var i = 0; i < arguments.length; i++) { 
      // Iterate over individual argument arrays (aka json1, json2)
      for(var j = 0; j < arguments[i].length; j++) {
         var currentID = arguments[i][j]['id'];
         if(!idMap[currentID]) {
            idMap[currentID] = {};
          }
         // Iterate over properties of objects in arrays (aka id, name, etc.)
        for(key in arguments[i][j]) {
            idMap[currentID][key] = arguments[i][j][key];
        }
      }
    }
  
    // push properties of idMap into an array
    var newArray = [];
    var property = ''
    for(property in idMap) {
      newArray.push(idMap[property]);
    }
    return newArray;
  }
  //-----------------------------------------------//
  //-----------------------------------------------//

  concatAll(){
    var options = this.state.matchups.map(function(row) {
      return { id : row.hero_id, games_played : row.games_played ,wins : row.wins }
   })
    var total=this.joinObjects(this.state.heroes, options)
    return total;
  }
 
    render() {
      var Stats;
    if(this.state.total){
       Stats = this.state.total.map(stat => (
        <MatchupCard
          key={stat.id}
          id={stat.id}
          win={stat.wins}
          pick={stat.games_played}
          localized_name={stat.localized_name}
          img={stat.img}/>
      ));
    }else{
       Stats = "Não existe"
    }

    return (
      <body>
        <Header></Header>
        <h3>Select Your Hero To See Matchups</h3>
        <DropdownHeros changeId={this.onChangeHeroisSelecionado.bind(this) }></DropdownHeros>
        <div className="grid">{Stats}</div>
      </body>
    );
  }
}
export default Matchups;
