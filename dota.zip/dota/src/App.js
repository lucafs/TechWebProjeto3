import React, { Component } from "react";
import "./App.css";
import axios from "axios";
import Herois from "./componentes/Herois";
import Header from "./componentes/Header";
import "bootstrap/dist/css/bootstrap.min.css";
import MenuItem from "@material-ui/core/MenuItem";
import FormControl from "@material-ui/core/FormControl";
import Select from "@material-ui/core/Select";
import DropdownHeroes from "./componentes/DropdownHeroes";
import Matchups from "./componentes/Matchups";
import { BrowserRouter as Router, Route } from "react-router-dom";

const URL = "https://api.opendota.com/api/heroStats";

class App extends Component {
  state = {
    data: [],
    rank: "",
    site: "https://api.opendota.com"
  };
  handleChange = event => {
    let name = event.target.name;
    this.setState({ [name]: event.target.value });
  };

  componentDidMount() {
    axios.get(URL).then(res => {
      this.setState({
        data: res.data,
        rank: "1",
        site: "https://api.opendota.com"
      });
    });
  }
  render() {
    console.log(this.state.data);
    const Stats = this.state.data.map(stat => (
      <Herois
        key={stat.id}
        id={stat.id}
        name={stat.name}
        localized_name={stat.localized_name}
        img={this.state.site + stat.img}
        pro_win={stat.pro_win}
        pro_pick={stat.pro_pick}
        win={stat[`${this.state.rank}_win`]}
        pick={stat[`${this.state.rank}_pick`]}
      />
    ));

    return (
      <body className=".App">
        <Router>
          <Route path="/matchup" exact component={Matchups} />
        </Router>
        <div className=".selectRank">
          <Header></Header>
          <FormControl className="center">
            <h2 className="title">Select your rank</h2>
            <Select
              name="rank"
              value={this.state.rank}
              onChange={this.handleChange}
            >
              <MenuItem value={1}>Herald</MenuItem>
              <MenuItem value={2}>Guardian</MenuItem>
              <MenuItem value={3}>Crusader</MenuItem>
              <MenuItem value={4}>Archon</MenuItem>
              <MenuItem value={5}>Legend</MenuItem>
              <MenuItem value={6}>Ancient</MenuItem>
              <MenuItem value={7}>Divine</MenuItem>
              <MenuItem value={8}>Imortal</MenuItem>
            </Select>
          </FormControl>
        </div>

        <div className="grid">{Stats}</div>
      </body>
    );
  }
}
export default App;
